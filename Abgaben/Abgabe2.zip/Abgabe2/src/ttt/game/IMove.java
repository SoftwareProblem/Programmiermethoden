package ttt.game;

public interface IMove {
    // Zeile auf dem Spielfeld
    int getRow();

    // Spalte auf dem Spielfeld
    int getColumn();
}
