package Hangman;

public enum Subject {
    Animals,Cars,Videogames,Softdrinks,Wuppi,Fluppi;
}
